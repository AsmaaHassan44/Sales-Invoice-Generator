package model;
import java.util.ArrayList;
public class fileoperations {
    public void readFile(ArrayList InvoiceLines) {

    }

    public void writeFile(ArrayList InvoiceLines) {

    }
}
